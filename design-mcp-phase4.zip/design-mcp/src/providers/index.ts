import { apiKeyFor, loadConfig } from "../config.js";
import type { ImageProvider, ImageRequest, ImageResult, TextProvider, TextRequest, TextResult } from "../types.js";
import { recordUsage } from "../usage.js";
import { anthropic } from "./anthropic.js";
import { googleImage, googleText } from "./google.js";
import { openaiImage, openaiText } from "./openai.js";

const TEXT: Record<string, TextProvider> = { anthropic, openai: openaiText, google: googleText };
const IMAGE: Record<string, ImageProvider> = { openai: openaiImage, google: googleImage };

/** Call whichever text provider/model is configured for a role. Config is re-read each call, so edits apply without restart. */
export async function generateText(role: "concept" | "builder" | "critic", req: TextRequest): Promise<TextResult> {
  const { provider, model } = loadConfig().config.roles[role];
  const result = await TEXT[provider].complete(model, apiKeyFor(provider), req);
  recordUsage({ role, provider, model, inputTokens: result.inputTokens, outputTokens: result.outputTokens, images: 0 });
  return result;
}

export async function generateImage(req: ImageRequest): Promise<ImageResult> {
  const { provider, model } = loadConfig().config.roles.image;
  const result = await IMAGE[provider].generate(model, apiKeyFor(provider), req);
  recordUsage({ role: "image", provider, model, inputTokens: 0, outputTokens: 0, images: 1 });
  return result;
}
