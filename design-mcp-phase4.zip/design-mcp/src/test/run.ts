import fs from "node:fs/promises";
import path from "node:path";
import { loadConfig, projectDir, stateDir, type TestConfig } from "../config.js";
import { serveDir } from "./server.js";
import {
  axeGate, basicsGate, contentVisibleGate, focusGate, INIT, loadMetricsGate, overflowGate, reducedMotionGate,
  runtimeGate, scrollThrough, smoothnessGate, tapTargetGate, tinyTextGate, type GateResult,
} from "./gates.js";
import { weightGate } from "./weight.js";

export interface TestReport {
  id: string;
  name: string;
  at: string;
  verdict: "pass" | "fail";
  hardFailures: GateResult[];
  warnings: GateResult[];
  passed: GateResult[];
  shots: string[];
}

const strict = (g: GateResult, cfg: TestConfig) => g.group === "runtime" || cfg.strictGroups.includes(g.group as "mobile" | "a11y" | "perf");

async function launch(cfg: TestConfig) {
  let pw: any;
  try {
    pw = await import("playwright");
  } catch {
    throw new Error("Playwright is not installed. In the design-mcp folder run: npm install && npx playwright install chromium");
  }
  try {
    return await pw.chromium.launch({ headless: true, ...(cfg.channel !== "chromium" ? { channel: cfg.channel } : {}) });
  } catch (e) {
    throw new Error(
      `Could not start the browser (${cfg.channel}). ${cfg.channel === "chromium" ? "Run: npx playwright install chromium (in the design-mcp folder), or set test.channel to \"chrome\" to use your installed Chrome." : "Is that browser installed?"}\n${e instanceof Error ? e.message.split("\n")[0] : e}`
    );
  }
}

async function open(browser: any, url: string, opts: any, errors: string[] | null) {
  const ctx = await browser.newContext(opts);
  const page = await ctx.newPage();
  await page.addInitScript(INIT);
  if (errors) {
    page.on("pageerror", (e: Error) => errors.push(`Script error: ${e.message.split("\n")[0]}`));
    page.on("console", (m: any) => {
      const t: string = m.text();
      if (m.type() === "error" && !/Failed to load resource|net::ERR/i.test(t)) errors.push(`Console error: ${t.slice(0, 160)}`);
    });
    page.on("response", (r: any) => {
      if (r.url().startsWith(url) && r.status() >= 400) errors.push(`Broken local file (${r.status()}): ${r.url().replace(url, "")}`);
    });
  }
  await page.goto(url, { waitUntil: "load" });
  await page.evaluate(() => (document as any).fonts?.ready).catch(() => {});
  await page.waitForTimeout(1200);
  return { ctx, page };
}

async function shoot(page: any, dir: string, prefix: string, viewportH: number, max: number): Promise<string[]> {
  const h: number = await page.evaluate(() => document.documentElement.scrollHeight);
  const n = Math.min(max, Math.max(1, Math.ceil(h / viewportH)));
  const files: string[] = [];
  for (let i = 0; i < n; i++) {
    await page.evaluate((y: number) => window.scrollTo(0, y), i * viewportH);
    await page.waitForTimeout(900);
    const file = path.join(dir, `${prefix}-${String(i + 1).padStart(2, "0")}.jpg`);
    await page.screenshot({ path: file, type: "jpeg", quality: 78 });
    files.push(file);
  }
  await page.evaluate(() => window.scrollTo(0, 0));
  return files;
}

export async function testVariation(o: { root: string; id: string; name: string; log: (m: string) => void }): Promise<TestReport> {
  const cfg = loadConfig().config.test;
  const { root, id, log } = o;
  const dist = path.join(root, "dist");
  if (!(await fs.access(path.join(dist, "index.html")).then(() => true, () => false))) {
    throw new Error(`No build found in ${path.relative(projectDir(), dist)}. Run design_build first.`);
  }
  const shotDir = path.join(stateDir(), "shots", id);
  await fs.rm(shotDir, { recursive: true, force: true });
  await fs.mkdir(shotDir, { recursive: true });

  const results: GateResult[] = [await weightGate(dist, cfg.budgets)];
  const shots: string[] = [];
  const errors: string[] = [];
  const server = await serveDir(dist);
  const browser = await launch(cfg);
  try {
    // Desktop
    log(`[${id}] desktop run`);
    const d = await open(browser, server.url, { viewport: { width: 1440, height: 900 } }, errors);
    results.push(await loadMetricsGate(d.page, cfg.budgets));
    results.push(await smoothnessGate(d.page, 900, cfg.budgets)); // also scrolls through, firing all animations
    results.push(await contentVisibleGate(d.page, "desktop"));
    results.push(await basicsGate(d.page));
    results.push(await axeGate(d.page, "desktop"));
    results.push(await focusGate(d.page));
    shots.push(...(await shoot(d.page, shotDir, "desktop", 900, 8)));
    await d.ctx.close();

    // Mobile (390 and 360, desktop-style emulation so sideways overflow is measured honestly)
    for (const w of [390, 360]) {
      log(`[${id}] mobile ${w}px run`);
      const m = await open(browser, server.url, { viewport: { width: w, height: w === 390 ? 844 : 740 }, deviceScaleFactor: 2, hasTouch: true }, null);
      await scrollThrough(m.page, w === 390 ? 844 : 740);
      results.push(await overflowGate(m.page, w));
      if (w === 390) {
        results.push(await tapTargetGate(m.page));
        results.push(await tinyTextGate(m.page));
        results.push(await axeGate(m.page, "mobile"));
        shots.push(...(await shoot(m.page, shotDir, "mobile", 844, 8)));
      }
      await m.ctx.close();
    }

    // Reduced motion
    log(`[${id}] reduced-motion run`);
    const r = await open(browser, server.url, { viewport: { width: 1440, height: 900 }, reducedMotion: "reduce" }, null);
    await scrollThrough(r.page, 900);
    results.push(await reducedMotionGate(r.page));
    results.push(await contentVisibleGate(r.page, "reduced-motion"));
    await r.ctx.close();
  } finally {
    await browser.close().catch(() => {});
    await server.close();
  }
  results.push(runtimeGate([...new Set(errors)]));

  const failing = results.filter((g) => !g.pass);
  const report: TestReport = {
    id, name: o.name, at: new Date().toISOString(),
    hardFailures: failing.filter((g) => strict(g, cfg)),
    warnings: failing.filter((g) => !strict(g, cfg)),
    passed: results.filter((g) => g.pass),
    verdict: failing.some((g) => strict(g, cfg)) ? "fail" : "pass",
    shots,
  };
  await saveReport(report);
  log(`[${id}] ${report.verdict.toUpperCase()}: ${report.hardFailures.length} blocking, ${report.warnings.length} warning(s)`);
  return report;
}

export function renderReport(r: TestReport): string {
  const block = (g: GateResult) => [`- [${g.group}] ${g.title}`, ...g.details.map((d) => `    ${d}`)].join("\n");
  return [
    `${r.id.toUpperCase()} "${r.name}": ${r.verdict.toUpperCase()}`,
    r.hardFailures.length ? `\nBLOCKING (${r.hardFailures.length}):\n${r.hardFailures.map(block).join("\n")}` : "",
    r.warnings.length ? `\nWARNINGS (${r.warnings.length}, not blocking):\n${r.warnings.map(block).join("\n")}` : "",
    `\nPASSED (${r.passed.length}): ${r.passed.map((g) => g.title).join("; ")}`,
    `\nScreenshots: ${r.shots.length ? path.dirname(r.shots[0]) : "none"}`,
  ].filter(Boolean).join("\n");
}

async function saveReport(r: TestReport) {
  const dir = path.join(stateDir(), "reports");
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(path.join(dir, `${r.id}.json`), JSON.stringify(r, null, 2));
  await fs.writeFile(path.join(dir, `${r.id}.md`), renderReport(r));
}

export async function loadReport(id: string): Promise<string> {
  try {
    return await fs.readFile(path.join(stateDir(), "reports", `${id}.md`), "utf8");
  } catch {
    throw new Error(`No report for "${id}". Run design_test first.`);
  }
}

export interface BuiltVariation { id: string; name: string; root: string; port: number; status: string }

export async function findVariations(): Promise<BuiltVariation[]> {
  const base = path.join(projectDir(), "variations");
  let dirs: string[] = [];
  try { dirs = await fs.readdir(base); } catch { return []; }
  const out: BuiltVariation[] = [];
  for (const d of dirs.sort()) {
    try {
      const m = JSON.parse(await fs.readFile(path.join(base, d, "design-mcp.json"), "utf8"));
      out.push({ id: m.conceptId, name: m.concept, root: path.join(base, d), port: m.port, status: m.status });
    } catch { /* not one of ours */ }
  }
  return out;
}
